// Copyright 2004-present Facebook. All Rights Reserved.

package com.facebook.messenger;

public class Messenger { }
